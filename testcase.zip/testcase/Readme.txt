Use "trainingFile" as the training file and use "testingFile" as the test file. You may run your program like:

java Word_nb trainingFile testingFile

You should include weka.jar in your CLASSPATH as well.

You can compare your output with the files in the "expect_output" folder.
